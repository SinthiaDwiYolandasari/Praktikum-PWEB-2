<?php

class HomeController{
    public function home(){
        header("location:http://localhost/sipemduwis/");
    }

    public function peserta(){
        header("location:http://localhost/sipemduwis/views/peserta/index.php");
    }
    // public function peserta(){
    //     header("location:http://localhost/sipemduwis/views/peserta/index.php");
    // }
}   
?>