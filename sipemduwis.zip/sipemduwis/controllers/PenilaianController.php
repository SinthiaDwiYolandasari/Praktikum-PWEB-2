<?php
include_once '../../models/Penilaian.php';

class PenilaianController{
    // properti model untuk me return di conctruct nya
    private $model;

    // membuat cons $db agar terhubung dua arah antara controller dengan model
    public function __construct($db){

        // instansiasi mahasiswa yang ada di models
        $this->model = new Penilaian($db);
    }

    public function getAllPenilaian(){
        return $this->model->getAllPenilaian();
    }

    // public function createPenilaian($tahap1,$tahap2,$tahap3,$pengetahuan,$keterampilan,$sikap,$total_nilai)
    // {
    //     return $this->model->createPenilaian($tahap1,$tahap2,$tahap3,$pengetahuan,$keterampilan,$sikap,$total_nilai);

    // }

    public function getPenilaianById($id_penilaian){
        return $this->model->getPenilaianById($id_penilaian);
    }

    // method untuk update
    public function updatePenilaian($id_penilaian,$tahap1,$tahap2,$pengetahuan1,$keterampilan1,$sikap1,$pengetahuan2,$keterampilan2,$sikap2,$total_nilai)
    {
        return $this->model->updatePenilaian($id_penilaian,$tahap1,$tahap2,$pengetahuan1,$keterampilan1,$sikap1,$pengetahuan2,$keterampilan2,$sikap2,$total_nilai);
    }
    // method untuk hapus
    public function deletePenilaian($id_penilaian){
        return $this->model->deletePenilaian($id_penilaian);
    }

    public function getIdPenilaianData (){
        return $this->model->getIdPesertaData();
    }
}
?>